﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DLRMSEntity;
using DLRMSException;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace DLRMSDAL
{
    public class DealerDAL
    {
        public static List<Dealer> dealers = new List<Dealer>();
        public bool AddDealerDAL(Dealer newDealer)
        {
            bool isDealerAdded = false;
            try
            {
                dealers.Add(newDealer);
                isDealerAdded = true;
            }
            catch(SystemException exception)
            {
                throw new DealerException(exception.Message);
            }
            return isDealerAdded;
        }

        public List<Dealer>GetAllDealerDAL()
        {
            return dealers;
        }
        public List<Dealer> SearchByProductCategoryDAL(string ProductCategory)
        {
            return dealers.FindAll(dealer => dealer.DealerProductCategory.Equals(ProductCategory));
        }
        public bool SerializeDealersDAL()
        {
            bool areDealersSerialized = false;
            try
            {
                FileStream fileStream = new FileStream("Dealers.ser", FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, dealers);
                fileStream.Close();
                areDealersSerialized = true;
            }
            catch (SystemException exception)
            {
                throw new DealerException(exception.Message);
            }

            return areDealersSerialized;

        }
        public List<Dealer> DeSerializeDealerDAL()
        {
            List<Dealer> DeserializedDealers;
            try
            {
                FileStream filestream = new FileStream("Dealers.ser", FileMode.Open);
                BinaryFormatter binaryformatter = new BinaryFormatter();
                DeserializedDealers = (List<Dealer>)binaryformatter.Deserialize(filestream);
                filestream.Close();


            }
            catch (SystemException exception)
            {
                throw new DealerException(exception.Message);
            }
            return DeserializedDealers;
        }
    }
}
