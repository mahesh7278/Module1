﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DLRMSEntity;
using DLRMSException;
using DLRMSDAL;
using System.Text.RegularExpressions;

namespace DLRMSBLL
{
    public class DealerBLL
    {
        DealerDAL dealerDAL = new DealerDAL();
        public bool AddDealerBLL(Dealer newDealer)
        {
            bool isDealerAdded = false;
            if(ValidateDealer(newDealer))
            {
                
                isDealerAdded =dealerDAL.AddDealerDAL(newDealer);
                isDealerAdded = true;
            }
            //To be implemented
            return isDealerAdded;
        }
        
        public List<Dealer> GetAllDealerBLL()
        {
           return  dealerDAL.GetAllDealerDAL();
        }
        public List<Dealer> SearchByProductCategoryBLL(string productcategory)
        {
            return dealerDAL.SearchByProductCategoryDAL(productcategory);
        }
        public bool SeializeDealerBLL()
        {
            return dealerDAL.SerializeDealersDAL();
        }
        public List<Dealer> DeSerializeDealersBLL()
        {
            return dealerDAL.DeSerializeDealerDAL();
        }
        private static bool ValidateDealer(Dealer dealer)
        {
            bool validDealer = true;
            StringBuilder message = new StringBuilder();
            if ((dealer.DealerId == string.Empty || dealer.DealerId == null) || !Regex.IsMatch(dealer.DealerId, @"DL[0-9]{4}$"))
            {
                message.Append(Environment.NewLine + "Invalid Dealer Id");
                validDealer = false;
            }
            if (dealer.DealerName == string.Empty || dealer.DealerName == null)
            {
                message.Append(Environment.NewLine + "Invalid Dealer Name");
                validDealer = false;
            }
            if (dealer.Address == string.Empty || dealer.Address == null)
            {
                message.Append(Environment.NewLine + "Invalid Address");
                validDealer = false;
            }
            if ((dealer.EmailId == string.Empty || dealer.EmailId == null) || !Regex.IsMatch(dealer.EmailId,
                @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z"))
            {
                message.Append(Environment.NewLine + "Invalid Email Address");
                validDealer = false;
            }
            if (dealer.DealerStatus != true && dealer.DealerStatus != false)
            {
                message.Append(Environment.NewLine + "Invalid Dealer Status");
                validDealer = false;
            }
            if ((dealer.DealerProductCategory == string.Empty || dealer.DealerProductCategory == null) || (dealer.DealerProductCategory.ToLower() != "food" && dealer.DealerProductCategory.ToLower() != "beverages"))
            {
                message.Append(Environment.NewLine + "Invalid Product Catagory");
                validDealer = false;
            }
            if ((dealer.PhoneNumber == string.Empty || dealer.PhoneNumber == null) || !Regex.IsMatch(dealer.PhoneNumber, @"[9,8,7][0-9]{9}$"))
            {
                message.Append(Environment.NewLine + "Invalid Phone Number");
                validDealer = false;
            }
            if (validDealer == false)
            {
                throw new DealerException(message.ToString());
            }
            return validDealer;
        }
    }
}
