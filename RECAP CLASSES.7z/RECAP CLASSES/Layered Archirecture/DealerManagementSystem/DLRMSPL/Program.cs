﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DLRMSEntity;
using DLRMSException;
using DLRMSBLL;

namespace DLRMSPL
{
    class Program
    {
       static DealerBLL dealerBLL = new DealerBLL();
        static void Main(string[] args)
        {
            byte choice;
            do
            {


                printMenu();
                Console.WriteLine("Enter your choice:");
                bool CheckChoice;
                CheckChoice = byte.TryParse(Console.ReadLine(), out choice);
                if(!CheckChoice)
                {
                    Console.WriteLine("Invalid Input");
                }
            
               // int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddDealerPL();
                        break;
                    case 2:
                        GetAllDealerPL();
                       break;
                    case 3:
                        SearchByProductCategoryPL();
                        break;

                    case 4:
                        SerailaizeDealersPL();
                        break;
                    case 5:
                        DeSerializeDealersPL();
                        break;


                    default:
                        Console.WriteLine("Invalid Choice.");
                        break;
                }

            } while (choice!=0);
        }
        private static void printMenu()
        {

            Console.WriteLine("\n***********Dealer Management System  ***********");
            Console.WriteLine("1. Add Dealer");
            Console.WriteLine("2.List All Dealers");
            Console.WriteLine("3. Search Dealer based on product category");
            Console.WriteLine("4. Serialize All Dealers");
            Console.WriteLine("5. Deserialize All Dealers");
            Console.WriteLine("6. Exit");
            Console.WriteLine("************************************\n");

        }
        private static void AddDealerPL()
        {
            try
            {
               //Accept input from user

                Console.WriteLine("Enter Dealer Id :");
                string DealerId = Console.ReadLine();
                Console.WriteLine("Enter Dealer Name :");
                string DealerName = Console.ReadLine();
                Console.WriteLine("Enter Dealer Address :");
                string Address = Console.ReadLine();
                Console.WriteLine("Enter Dealer Email ID :");
                string EmailId = Console.ReadLine();
                Console.WriteLine("Enter Dealer Phone No :");
                string PhoneNumber = Console.ReadLine();
                Console.WriteLine("Enter Dealer Status :");
                bool DealerStatus = bool.Parse(Console.ReadLine());
                Console.WriteLine("Enter Dealer Product Category :");
                string DealerProductCategory = Console.ReadLine();

                //pass input to create new object

                Dealer newDealer = new Dealer();
                newDealer.DealerId = DealerId;
                newDealer.DealerName = DealerName;
                newDealer.Address= Address;
                newDealer.EmailId = EmailId;
                newDealer.PhoneNumber = PhoneNumber;
                newDealer.DealerStatus= DealerStatus;
                newDealer.DealerProductCategory = DealerProductCategory;


                DealerBLL dealerBLL = new DealerBLL();
                bool isNewDealerAdded = dealerBLL.AddDealerBLL(newDealer);
                if(isNewDealerAdded)
                {
                    Console.WriteLine("Dealer Added Successfully");
                }
                else
                {
                    Console.WriteLine("Failed to Add Dealer");
                }

            }
            catch (DealerException exception)
            {
                Console.WriteLine("Exception Occured." + exception.Message);
            }

        }
        public static void GetAllDealerPL()
        {
            List<Dealer> DealerList = dealerBLL.GetAllDealerBLL();
            DisplayList(DealerList);
            //Console.WriteLine("********************************************************************");
            //Console.WriteLine("DealerId"+"\t"+ "DealerName" + "\t" +"DealerAddress" + "\t" + "DealerEmailId" + "\t" + "DealerPhoneNumber" + "\t" + "DealerStatus" + "\t" + "DealerProductCategory" );
            //Console.WriteLine("********************************************************************");
            //foreach (Dealer dealer in DealerList)
            //{
            //    Console.WriteLine(dealer.DealerId+"\t" +dealer.DealerName+"\t"+dealer.Address+"\t"+dealer.EmailId+"\t"+dealer.PhoneNumber+"\t"+dealer.DealerStatus+"\t"+dealer.DealerProductCategory);
            //}
            //Console.WriteLine("*******************************************************************");
        }
        public static void SearchByProductCategoryPL()
        {
            Console.WriteLine("Enter product category");
            string productcategory = Console.ReadLine();
            List<Dealer> SearchDealers = dealerBLL.SearchByProductCategoryBLL(productcategory);
            DisplayList(SearchDealers);
            //Console.WriteLine("********************************************************************");
            //Console.WriteLine("DealerId" + "\t" + "DealerName" + "\t" + "DealerAddress" + "\t" + "DealerEmailId" + "\t" + "DealerPhoneNumber" + "\t" + "DealerStatus" + "\t" + "DealerProductCategory");
            //Console.WriteLine("*****************************************************************************************************************");
            //foreach (Dealer dealer in SearchDealers)
            //{
            //    Console.WriteLine(dealer.DealerId + "\t" + dealer.DealerName + "\t" + dealer.Address + "\t" + dealer.EmailId + "\t" + dealer.PhoneNumber + "\t" + dealer.DealerStatus + "\t" + dealer.DealerProductCategory);
            //}
            //Console.WriteLine("****************************************************************************************************************");
        }
        private static void SerailaizeDealersPL()
        {
           
            if(dealerBLL.SeializeDealerBLL())
            {
                Console.WriteLine("Dealers Details Added Successfully");
            }
            else
            {
                Console.WriteLine("Failed to Add Dealer Details");
            }
        }
        private static void DeSerializeDealersPL()
        {
            List<Dealer> DeSerializedDealers = dealerBLL.DeSerializeDealersBLL();
            DisplayList(DeSerializedDealers);
            //Console.WriteLine("********************************************************************************************************************************");
            //Console.WriteLine("DealerId" + "\t" + "DealerName" + "\t" + "DealerAddress" + "\t" + "DealerEmailId" + "\t" + "DealerPhoneNumber" + "\t" + "DealerStatus" + "\t" + "DealerProductCategory");
            //Console.WriteLine("******************************************************************************************************************");
            //foreach (Dealer dealer in DeSerializedDealers)
            //{
            //    Console.WriteLine(dealer.DealerId + "\t" + dealer.DealerName + "\t" + dealer.Address 
            //        + "\t" + dealer.EmailId + "\t" + dealer.PhoneNumber + "\t" + dealer.DealerStatus 
            //        + "\t" + dealer.DealerProductCategory);
            //}
            //Console.WriteLine("*******************************************************************************************************************************");
        }
        public static void DisplayList(List<Dealer> dealers)
        {
            Console.WriteLine("DealerID" + "\t" + "DealerName" + "\t" + "Address" + "\t" + "EmailId" + "\t" + "PhoneNumber" + "\t" + "Dealerstatus" + "\t" + "product category");
            foreach (Dealer dealer in dealers)
            {
                Console.WriteLine(dealer.DealerId + "\t" + dealer.DealerName + "\t" + dealer.Address+ "\t" + dealer.EmailId + "\t" + dealer.PhoneNumber + "\t" + dealer.DealerStatus + "\t" + dealer.DealerProductCategory);
            }
        }
    }
}
