﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodDemo
{
   static  class newStringClass
    {
        public static void print(this String str,string name)
        {
            string stringname = name.ToUpper();
            int i = 1;
            StringBuilder b = new StringBuilder(name);
            for(i=1;i<=name.Length-1;i=i+2)
            {
                char c = char.ToUpper(b[i]);
                b.Replace(b[i], c);
            }
            Console.WriteLine(b);
        }
    }
}
