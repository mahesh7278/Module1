﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OtherDemos
{
    class Person
    {

        public virtual void DoJob()
        {
            Console.WriteLine("Person is doing his/her job");
        }
    }
    class Employee : Person
    {
        public override void DoJob()
        {

            Console.WriteLine("Employee is doinghis/her job");
        }
    }
    //public void DoJob()
    //{
    //    Console.WriteLine("Employee is doinghis/her job");
    //}
}
