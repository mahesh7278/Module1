﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OtherDemos
{
   static class Int32Extensions
    {
        public static int Add(this int no, int x)
        {
            return no +x;
        }
        public static string Greet(this string userName,string str)
        {
          return userName+str;
        }
    }
}
