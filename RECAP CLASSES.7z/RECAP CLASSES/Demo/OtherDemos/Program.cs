﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;


namespace OtherDemos
{
   
    class Program:IEnumerable
    {
        static void Main(string[] args)
        {
            /*
              int no = 10;
              int res = no.Add(4);
              Console.WriteLine("Result is:"+res);

              string userName = "khaleelshannu";
              string userGreeting = userName.Greet(" Good Morning ");
              Console.WriteLine(userGreeting);
              Console.ReadKey();
            */
            /*
 
               ////Overriding Demo
               //Person person = new Person();
               //person.DoJob();

                 Employee employee = new Employee();
                 employee.DoJob();

                Person employee2 = new Employee();
                employee2.DoJob();///Employee is ionning thejob
            */
            //   File Handling - File-System-Info Properties
            //Drive - Directories - Files

            //DriveInfo[] driveInfos=DriveInfo.GetDrives();
            //foreach(DriveInfo dInfo in driveInfos)
            //{
            //    Console.WriteLine("driveName: " + dInfo.Name + ", VolumeLabel:" + dInfo.VolumeLabel+ ",Drive Type:" + dInfo.DriveType);
            //    Console.WriteLine("");
            //    Console.WriteLine("\n Drive Name:" +dInfo.Name);

            //    DirectoryInfo directoryInfo = new DirectoryInfo(dInfo.Name);
            //    DirectoryInfo[] dirs = directoryInfo.GetDirectories();
            //    Console.WriteLine("\n\tFolder List:");
            //    foreach (DirectoryInfo d in dirs)
            //    {
            //        Console.WriteLine(d.Name); //Temp

            //    }
            //    FileInfo[] files = directoryInfo.GetFiles();
            //    foreach(FileInfo f in files)
            //    {
            //        Console.WriteLine(f);
            //    }
            //}
            //  Console.ReadKey();
            //}
            //}
            //int[] numbers = NumberRangeGenerator.GenerateNumber(1, 10);
            //foreach (var item in numbers)
            //{
            //    Console.WriteLine(item);
            //}
            //  }
            foreach (var item in NumberRangeGenerator.GenerateNumber(5, 10))
            {
                Console.WriteLine(item);
            }

            //MyCollection obj = new MyCollection();
            //foreach (var item in obj)
            //{

            //}
            Console.ReadKey();
        }

        public IEnumerator GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }




}

