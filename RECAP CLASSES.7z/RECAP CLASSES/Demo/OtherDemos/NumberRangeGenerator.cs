﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace OtherDemos
{
    class MyCollection:IEnumerable
    {
        public IEnumerator GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
    class NumberRangeGenerator
    {
        //C#-3.0-Iterator Method
        //  static   public int[] GenerateNumber(int minNum, int maxNum) //4,8->4,5,6,7,8
        static public IEnumerable GenerateNumber(int minNum, int maxNum) 
        {
            //int[] arr = new int[(maxNum - minNum) + 1];
            // for(int i=minNum, x=0;  i<=maxNum;i++,x++)
            for (int i = minNum;  i <= maxNum; i++)

            {
                yield return i;
                //arr[x] = i;
            }
           // return arr;
        }
    }
}
