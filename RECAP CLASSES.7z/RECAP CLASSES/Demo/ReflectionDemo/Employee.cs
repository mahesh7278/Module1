﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionDemo
{
   public  class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public double Salary { get; set; }
        public DateTime Dateofjoining { get; set; }

        public string GetEmpInfo()
        {
            return $"EmpId:{EmpId}, Name:{EmpName}, Salary:{Salary},Dateofjoining:{Dateofjoining}";
        }
        public bool MinSalaryCheck(double minSalary)
        {
            return Salary >= minSalary;
        }
    }
}
