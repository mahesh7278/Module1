﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using UD_Attributes;
using EMS_Entities;

namespace ProjectAttribute
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly asm = Assembly.LoadFrom(@"C:\Dot Net Training\RECAP CLASSES\Demo\EMS_Entities\bin\Debug\EMS_Entities.dll");
            Type t = asm.GetType("EMS_Entities.Manager");
           
            ProjectInfoAttribute dia = (ProjectInfoAttribute)Attribute
         .GetCustomAttribute(t,typeof(ProjectInfoAttribute));
            Console.WriteLine("Project Name:" +dia.ProjectName);
            Console.WriteLine("Project Lead:" +dia.ProjectLead);


        }
    }
}
