﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UD_Attributes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
    public class ProjectInfoAttribute : Attribute
    {



        public string ProjectName { get; set; }
        public string ProjectLead{get;set;}

            public ProjectInfoAttribute(string projectName,string projectLead)
            {
                ProjectName = projectName;
                 ProjectLead = projectLead;
            }
        }
    }