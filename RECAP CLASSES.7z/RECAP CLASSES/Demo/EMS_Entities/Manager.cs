﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UD_Attributes;

namespace EMS_Entities
{
    //[DeveloperInfo("Khaleel")]
    [ProjectInfoAttribute("WIPO","khaleel")]
   public class Manager
    {

    }
}
