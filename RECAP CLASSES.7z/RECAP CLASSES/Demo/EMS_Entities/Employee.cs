﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UD_Attributes;

namespace EMS_Entities
{
    //[DeveloperInfo("Khaleel")]
    //[DeveloperInfo("Shannu")]
    [ProjectInfoAttribute("PIZZERIA","Shannu")]
    public class Employee
    {
       // [DeveloperInfo("Khaleel")]

        public void M1()
       {

        }
    }
}
