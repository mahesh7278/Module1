﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UD_Attributes;
using EMS_Entities;
using System.Reflection;

namespace AttributeDemo
{
    class Program
    {
        //    [Obsolete("This is tooo old functionality.use instead M2!",true)]
        //    static void M1()
        //    {
        //        Console.WriteLine("This is functionality to send Indian Post mail");
        //    }
        //    static void M2()
        //    {
        //        Console.WriteLine("This is functionality to send Email");
        //  }
    
        static void Main(string[] args)
        {
            //M1();
            //M2();

            //Assembly asm = Assembly.LoadFrom(@"C:\Dot Net Training\RECAP CLASSES\Demo\EMS_Entities\bin\Debug\EMS_Entities.dll");
            // Type t = asm.GetType("EMS_Entities.Employee");

            //    DeveloperInfoAttribute dia = (DeveloperInfoAttribute)Attribute
            //  .GetCustomAttribute(t, typeof(DeveloperInfoAttribute));
            DeveloperInfoAttribute dia = (DeveloperInfoAttribute)Attribute
          .GetCustomAttribute(typeof(Manager), typeof(DeveloperInfoAttribute));
            DeveloperInfoAttribute dia1 = (DeveloperInfoAttribute)Attribute
          .GetCustomAttribute(typeof(Employee), typeof(DeveloperInfoAttribute));

            Console.WriteLine(dia.DeveloperName);
            Console.WriteLine(dia1.DeveloperName);

        }
    }
}
