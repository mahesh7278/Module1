﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;
using System.Xml.Serialization;


namespace SerializaionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Product> product = new List<Product>()
            {
                new Product{ ProductId=123,Name="CoolPad",Price=120,Quantity=20 },
                new Product{ ProductId=124,Name="samsung",Price=140,Quantity=60 },
                new Product{ ProductId=125,Name="vivo",Price=160,Quantity=9 }
            };
            //SerializeProducts(product);
            //DeSerializeProducts();
            //SoapSerializaion(product.ToArray());
            //DeSoapSerializaion();
            XmlSerializaion(product.ToArray());
            XmlDeSerializaion();

         }
        static void SerializeProducts(List<Product> product)
        {
            FileStream fs = new FileStream("Products.dat", FileMode.Create, FileAccess.Write);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(fs, product);
            fs.Close();
            Console.WriteLine("Product data written successfully");

        }
        static void DeSerializeProducts()
        {
            FileStream fs = new FileStream("Products.dat", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            List<Product> product=formatter.Deserialize(fs) as List<Product>;
            fs.Close();
            foreach (var p in product)
            {
                Console.WriteLine("{0,-4}|{1,-20}|{2,-5}|{3,-5}", p.ProductId,p.Name,p.Price,p.Quantity);
            }
            Console.WriteLine("Product data written successfully");
        }
        static void SoapSerializaion(Product[] product)
        {
            FileStream fs = new FileStream("soapdata.xml", FileMode.Create, FileAccess.Write);
            SoapFormatter formatter = new SoapFormatter();
            formatter.Serialize(fs, product);
            fs.Close();
            Console.WriteLine("Serialized the data to soap format");

        }
        static void DeSoapSerializaion() 
        {
            FileStream fs = new FileStream("soapdata.xml", FileMode.Open, FileAccess.Read);
            SoapFormatter formatter = new SoapFormatter();
            Product[] product = formatter.Deserialize(fs) as Product[];
            fs.Close();
            foreach (var p in product)
            {
                Console.WriteLine("{0,-4}|{1,-20}|{2,-5}|{3,-5}", p.ProductId, p.Name, p.Price, p.Quantity);
            }
            Console.WriteLine("Product data written successfully");
        }
        static void XmlSerializaion(Product[] product)
        {
            FileStream fs = new FileStream("xmldata.xml", FileMode.Create, FileAccess.Write);
            XmlSerializer ser = new XmlSerializer(typeof(Product []));
            ser.Serialize(fs, product);
            fs.Close();
            Console.WriteLine("serialize to xml format");
        }
        static void XmlDeSerializaion()
        {
            FileStream fs = new FileStream("xmldata.xml", FileMode.Open, FileAccess.Read);
            XmlSerializer ser = new XmlSerializer(typeof(Product[]));
            Product[] product =ser.Deserialize(fs) as Product[];
            fs.Close();
            foreach (var p in product)
            {
                Console.WriteLine("{0,-4}|{1,-20}|{2,-5}|{3,-5}", p.ProductId, p.Name, p.Price, p.Quantity);
            }
            Console.WriteLine("Product data written successfully");
        

        }
    }
    
}
