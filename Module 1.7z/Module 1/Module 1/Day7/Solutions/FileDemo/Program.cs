﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace FileDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            //file class
            FileStream fs = File.Create("Sample.txt");
            fs.Close();
            Console.WriteLine("press enter to delete the file");
            Console.ReadLine();
            File.Delete("Sample.txt");
            bool exists = File.Exists("Demo.txt");
            if (exists)
            {
                Console.WriteLine("File Exists");
            }
            else
            {
                Console.WriteLine("File not exist");
            }

            //Directory Class
            Directory.CreateDirectory("MyData");
            Console.WriteLine("press enter to delete the file");
            Console.ReadLine();
            Directory.Delete("MyData");


            //FileInfo
            FileInfo finfo = new FileInfo(@"C:\Users\Public\Desktop\Acceptable_IT_Usage_Policy_v_4.6.pdf");
            Console.WriteLine("name:"+finfo.Name);
            Console.WriteLine("FullNmae:" + finfo.FullName);
            Console.WriteLine("filesize:" + finfo.Length + "bytes");
            Console.WriteLine("last access time:" + finfo.LastAccessTime);
            Console.WriteLine("Is readonly:" + finfo.IsReadOnly);
            Console.WriteLine("Creation Time:"+finfo.CreationTime);


            ////Directory Info
            DirectoryInfo dinfo = new DirectoryInfo(@"C:\Program Files");
            Console.WriteLine("name:" + dinfo.Name);
            Console.WriteLine("FullNmae:" + dinfo.FullName);
            Console.WriteLine("last access time:" + dinfo.LastAccessTime);
            Console.WriteLine("Creation Time:" + dinfo.CreationTime);
            foreach (DirectoryInfo dir in dinfo.GetDirectories())
            {
                Console.WriteLine(dir.Name);
            }
            foreach (FileInfo file in dinfo.GetFiles())
            {
                Console.WriteLine(file.Name);
            }
            Console.ReadLine();
        }
    }
}
