﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileDemo
{
    class Program2
    {
        static void Main()
        {
            //creating
            //FileStream fs = new FileStream("Sample.txt", FileMode.CreateNew, FileAccess.Write);
            FileStream fs = File.Create("Sample.txt");
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine("this is sample file demo");
            sw.WriteLine("this is another line in the file");
            sw.Flush();
            sw.Close();

            //reading
            fs = new FileStream("Sample.txt", FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string con = sr.ReadToEnd();
            Console.WriteLine(con);
            sr.Close();
            sr.Close();
            Console.ReadLine();
            
        }
    }
}
