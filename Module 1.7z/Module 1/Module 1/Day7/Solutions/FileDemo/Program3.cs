﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileDemo
{
    class Program3
    {
        static void Main()
        {
            FileStream fs = new FileStream("Bindata.dat", FileMode.Create, FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write("binary text");
            bw.Close();
            fs.Close();


            fs = new FileStream("Bindata.dat", FileMode.Open, FileAccess.Read);
            BinaryReader br = new BinaryReader(fs);
            var con = br.ReadString();
            Console.WriteLine(con);
            br.Close();
            fs.Close();

        }
    }
}
