﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionDemo
{
    class Program3
    {
        static void Main()
        {
            Stack<int> s = new Stack<int>();
            s.Push(12);
            s.Push(45);
            s.Push(78);
            s.Push(56);
            s.Push(65);
            Console.WriteLine("peek item is:"+s.Peek());
            Console.WriteLine("poped item is:"+s.Pop());
            Console.WriteLine("poped item is:"+s.Pop());


            //Queue
            Queue<int> q = new Queue<int>();
            q.Enqueue(19);
            q.Enqueue(46);
            q.Enqueue(45);
            q.Enqueue(67);
            q.Enqueue(198);
            q.Enqueue(87);


            Console.WriteLine("peek item is:" + q.Peek());
            Console.WriteLine("Dequeue item is:"+q.Dequeue());
            Console.WriteLine("Dequeue item is:" + q.Dequeue());
            Console.WriteLine("Dequeue item is:" + q.Dequeue());
        }
    }
}
