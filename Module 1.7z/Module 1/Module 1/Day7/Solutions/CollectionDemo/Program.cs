﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();
            list.Add(22);
            list.Add(98);
            list.Add(76);
            list.Add(27);
            list.Add(54);

            //printing
            Console.WriteLine("Items in List:"+list.Count);
            PrintList(list);

            //other methods
            list.Insert(3, 76);
            PrintList(list);

            list.Remove(1);
            PrintList(list);

            list.Reverse();
            PrintList(list);

            list.Sort();
            PrintList(list);

            Console.WriteLine($" 75 is exist in the list:{list.Contains(75)}");
            Console.WriteLine($" 76 is exist in the list:{list.Contains(76)}");

            Console.WriteLine($"position of 25 in the list:{list.IndexOf(25)}");
            Console.WriteLine($"position of 76 in the list:{list.IndexOf(76)}");

            Console.WriteLine($"position of 76 in the list:{list.LastIndexOf(76)}");

            //converting list into static it returns copy of array ,existing list is always remains same
            int[] ar = list.ToArray();

            //Addrange is adding group of elements
            list.AddRange(new int[] { 3, 76, 7, 90 });
            PrintList(list);

            //Extenstive methods are not present in list class 

            int total = list.Sum();
            Console.WriteLine($"total of all numbers is:{total}");

            int total2= list.Sum(p => p > 50 ? p : 0);
            Console.WriteLine($"total of all numbers  greater than 50 is:{total2}");

            int cnt = list.Count(p => p > 50);
            Console.WriteLine($"count of numbers greater than 50 is:{cnt}");

            //list.Clear();
            //list.RemoveAll(p => p > 50);

            Console.ReadLine();

        }
        static void PrintList(List<int> list)
        {
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("-----------------------------------");
        }

    }
}
