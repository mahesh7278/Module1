﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionDemo
{
    class Program2
    {
        static void Main()
        {
            Dictionary<string, long> contacts = new Dictionary<string, long>();

            contacts.Add("harika", 1234562346);
            contacts.Add("Malli", 9876540989);
            contacts.Add("sandy", 34567890678);
            contacts.Add("paru", 9876543269);
            contacts.Add("siri", 95553719785);
            PrintContacts(contacts);

            var keylist = contacts.Keys;
            foreach (var  v in keylist)
            {
                Console.WriteLine(v);
            }

            var valuelist = contacts.Values;
            foreach (var v in valuelist)
            {
                Console.WriteLine(v);
            }

            contacts.Remove("paru");//specify key
            PrintContacts(contacts);

            Console.WriteLine($" sandy exist in the key dictionary :{contacts.ContainsKey("sandy")}");
            Console.WriteLine($" 9876540989 is exist in the value Dictionary:{contacts.ContainsValue(9876540989)}");

        }
        static void PrintContacts(Dictionary<string,long> contacts)
        {
            foreach (var item in contacts)
            {
                Console.WriteLine($"{item.Key} =>{item.Value}");
            }
            Console.WriteLine("----------------------------------------");
        }
    }
}
