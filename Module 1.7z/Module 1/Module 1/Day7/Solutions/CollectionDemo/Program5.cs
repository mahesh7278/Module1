﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionDemo
{
    class Program5
    {
        
        //interface MyInterface<T>
        //{
        //    void DoSomething(T args);
           
        //}
        //class Cube : MyInterface<int>
        //{
        //    public int Side { get; set; }
        //    void MyInterface<int>.DoSomething(int args)
        //    {
        //        Console.WriteLine( Side*Side*Side);
        //    }
        //}
        //class Contacts : MyInterface<string>
        //{
        //    void MyInterface<string>.DoSomething(string arg)
        //    {
        //        Console.WriteLine(arg);
        //    }
        //}

        static void Main()
        {
            foreach (var item in GetItems())
            {
                Console.WriteLine(item);
            }
            DaysOfWeek d = new DaysOfWeek();
            foreach (var day in d)
            {
                Console.WriteLine(day);
            }

        }
        static IEquatable<int> GetItems()
        {
            yield return 1;
            yield return 2;
            yield return 3;
            yield return 4;

        }

    }
    class DaysOfWeek:IEnumerable
    {
        private string[] day = { "sun", "mon", "Tue" };
        public IEnumerator GetEnumerator()
        {
            for (int i = 0; i <day.Length; i++)
            {
                yield return days[i];
            }
        }

    }
}
