﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetSetProperty
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.EmpName = "malli";
            emp.Age = 9;
            emp.EmpId=1234;



            // Access
            Console.WriteLine(emp.EmpName);
            Console.WriteLine(emp.Age);
            Console.WriteLine(emp.EmpId);
            Console.WriteLine(emp.Salary);

        }
    }
}
