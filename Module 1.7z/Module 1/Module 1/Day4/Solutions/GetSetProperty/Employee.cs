﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetSetProperty
{
    class Employee
    {
        int empId;
        string empName;
        double salary;
        int age;
        string password;
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                if(value<18)
                {
                    Console.WriteLine("age to be set");
                }
                else
                {
                    Console.WriteLine("age is not be set");
                }
            }
        }
        public string Password
        {
            //get
            //{
            //    return password;
            //}
            set
            {
                password = value;
            }
        }
        public int EmpId
        {
            get
            {
                return empId;
            }
            set
            {
                EmpId = empId;
            }
        }
        public string EmpName
        {
            get
            {
               return empName;
            }
            set
            {
                EmpName=empName;
            }
        }
        public double Salary
        {
            get
            {
                return salary;
            }
            //set
            //{
            //    EmpId = empId;
            //}
        }
       

    }
}
