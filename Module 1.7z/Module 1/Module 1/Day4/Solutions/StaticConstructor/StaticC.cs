﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructor
{
    //Static class

    static class StaticC
    {
        
        //Static Data Members
        public static int count;
        static StaticC()
        {
            count = 1;
            

        }
        public static void Increment()
        {
            count = count + 1;
            Console.WriteLine("count is:" + count);

        }
        
    }
}
