﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            /*StaticC s1 = new StaticC();
            s1.Increment();
            Console.WriteLine(StaticC.count);
            StaticC s2 = new StaticC();
            s2.Increment();
            StaticC s3 = new StaticC();
            s3.Increment();
            Console.ReadLine();*/
            StaticC.Increment();
            

            
          

        }
    }
}
