﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureDemo
{
   class Program
    {
        static void Main(string[] args)
        {
            Coords c1 = new Coords(12, 45);
            

        }
    }
}
