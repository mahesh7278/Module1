﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureDemo
{
    public struct Coords
    {
        int a, b;
        //public Coords()
        //{

        //}
        public Coords(int num1,int num2)
        {
            a = num1;
            b = num2;
            Console.WriteLine(a);
            Console.WriteLine(b);

        }
        
    }
}
