﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureAccount
{
    class Program
    {
        static void Main(string[] args)
        {
            Account Acc1 = new Account(1244456, "harika", 12345);
            Acc1.Deposit(123);
            Acc1.Withdraw(87);

            Account Acc2 = new Account(126543, "vidya", 765432);
            Acc1.Deposit(123);
            Acc1.Withdraw(87);

            //Account Acc4;
            //int accountNum=1243, balance=12345;
            //string name="mal";
            //Acc4.accountNum;
            //Acc4.name;
            //Acc4.balance;


        }
    }
}
