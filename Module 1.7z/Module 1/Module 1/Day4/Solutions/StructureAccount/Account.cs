﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureAccount
{
   public struct Account
    {
        public int accountNum;
        public string name;
        public double balance;
        public Account(int num,string nm,double bal)
        {
            accountNum = num;
            name = nm;
            balance = bal;
        }
        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine("After balance deposit :" + balance);
        }
        public void Withdraw(double amount)
        {
            balance = balance - amount;
            Console.WriteLine("After balance withdraw:" + balance);
        }

    }
}
