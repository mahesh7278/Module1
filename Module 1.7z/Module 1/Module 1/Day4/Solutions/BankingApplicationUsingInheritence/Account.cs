﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApplicationUsingInheritence
{
    class Account
    {
        public int accountNumber ;
        public double balance;
        public string accountHolderName ;
        public Account(int accNum,double bal,string acnm)
        {
            accountNumber = accNum;
            balance = bal;
            accountHolderName = acnm;
        }
        public void Deposit(double amoount)
        {
            balance = balance + amoount;
            Console.WriteLine("after deposit availble balance:"+balance);
        }
        public virtual void Withdraw(double amount)
        {
            balance = balance - amount;
            Console.WriteLine("after withdraw availble balance:" + balance);
        }
    }
}
