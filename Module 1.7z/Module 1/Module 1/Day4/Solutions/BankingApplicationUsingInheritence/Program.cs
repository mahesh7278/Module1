﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApplicationUsingInheritence
{
    class Program
    {
        static void Main(string[] args)
        {
            SavingAccount sav = new SavingAccount(23545, 3456.9098, "sweety");
            sav.Deposit(1000);
            Console.ReadLine();
            sav.Withdraw(45);
            Console.ReadLine();
            sav.CreditCard();

            CurrentAccount cua = new CurrentAccount(45678,45676.9876,"chitti");
            cua.Deposit(56);
            Console.ReadLine();
            cua.Withdraw(96);
            Console.ReadLine();
            cua.Insurence();

            Console.ReadLine();

        }
    }
}
