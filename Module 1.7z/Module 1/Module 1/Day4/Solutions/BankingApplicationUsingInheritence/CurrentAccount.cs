﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApplicationUsingInheritence
{
    class CurrentAccount:Account
    {
        public CurrentAccount(int accNum1, double bal1, string acnm1):base(accNum1,bal1,acnm1)
        {
            
        }
        public override void Withdraw(double amount)
        {
            Console.WriteLine("saving account withdraw is called");
            if (balance - amount < 1000)
            {
                Console.WriteLine("Insufficent balance");
            }
            else
            {
                balance = balance - amount;
                Console.WriteLine("after withdraw availble balance:" + balance);
            }
        }
        public void Insurence()
        {
            Console.WriteLine("you are eliglible for free insurence");
        
        }
    }
}
