﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDefinedException
{
    class InvalidNameException:Exception
    {
        private string msg = "Invalid name value entered";
        public override string Message
        {
            get
            {
                return msg;
            }
        }
        public override string ToString()
        {
            return this.GetType() + " ," + msg;
        }

    }
}
