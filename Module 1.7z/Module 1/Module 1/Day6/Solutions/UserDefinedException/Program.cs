﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDefinedException
{
    class Program
    {
        static void Main(string[] args)
        {
            
            try
            {
                Console.WriteLine("enter name");
                string name = Console.ReadLine();
                if(name.Length<5)
                {
                  throw new InvalidNameException();
                   
                }
                Console.WriteLine("enter Age");
                int age = Convert.ToInt32(Console.ReadLine());
                if ((age<10) || (age>120))
                {
                    throw new InvalidAgeException();
                }
            }
            catch (InvalidNameException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (InvalidAgeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();

        }
    }
}
