﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EventDelegateDemo
{
    delegate void EventExecuter();
    class BoillingPlant
    {
        public event EventExecuter onClick;
        public void BoilWater()
        {
            for(int i=1;i<=150;i++)
            {
                Console.WriteLine("Temp :"+i);
                Thread.Sleep(1000);
                if(i==100)
                {
                    Console.WriteLine("Water boiled..");
                    onClick?.Invoke();
                }
            }
        }
    }
}
