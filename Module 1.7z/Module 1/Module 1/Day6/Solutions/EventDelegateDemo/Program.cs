﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDelegateDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            BoillingPlant b = new BoillingPlant();
            //here we can use new operator calling

            //1) calling mathods with name

            //b.onClick += RingBell;
            //b.onClick += SendNotification;
            
            //2)directly calling and assigning using Anonymously function
            b.onClick += delegate ()
             {
                 Console.WriteLine($"Bell Started Ringing");
             };
            b.onClick += delegate ()
             {
                 Console.WriteLine($"Shuting down...");
             };


            b.BoilWater();
            Console.ReadLine();

        }
        //static void RingBell()
        //{
        //    Console.WriteLine($"Bell Started Ringing");
        //}
        //static void ShutDown()
        //{
        //    Console.WriteLine($"Shuting down...");
        //}
        static void SendNotification()
        {
            Console.WriteLine($"sending message...");
        }
    }
}
