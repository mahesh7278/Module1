﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodsandLamdas
{
    class Program
    {
        delegate void MyDelegate(string str);
        delegate int CalculatorDelegate(int x, int y);
        static void Main(string[] args)
        {
            MyDelegate d1 = new MyDelegate(Show);  //named
            d1.Invoke("hello world");
            MyDelegate d2 = delegate (string str)//Ananoymous
            {
                Console.WriteLine("message is " + str);
            };
            d2.Invoke("make Noise");

            CalculatorDelegate c1 = Add;
            int sum1 = c1.Invoke(5, 6);
            Console.WriteLine("sum1 is" + sum1);

            CalculatorDelegate c2 = delegate (int a, int b)
             {
                 return a + b;
             };
            int sum2 = c2.Invoke(3, 6);
            Console.WriteLine("sum is" + sum2);

            //Lamda

            CalculatorDelegate c3 = (a, b) => a + b;
            int sum3 = c3.Invoke(4, 6);
            Console.WriteLine(sum3);

            //Lamda Stetement

            MyDelegate d3 = (s) =>
            {
                Console.WriteLine("message is:" + s);
            };



        }


        static void Show(String msg)
        {
            Console.WriteLine("message is");
        }
        static int Add(int a, int b)
        {
            return a + b;
        }
    }
}
                                                                                                                                                  