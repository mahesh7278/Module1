﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    class Program
    {
        static void Main(string[] args)
        {



            Calculator c = new Calculator();
           
            //Single Delegate


            MyDelegate d1 = new MyDelegate(c.Add);
            MyDelegate d2 = new MyDelegate(c.Subtract);

            // Type1


            //int sum=d1(2, 6);
            //int sub=d2(3, 6);
            //Console.WriteLine(sum);
            //Console.WriteLine(sub);


            //Type2

            //Executor(d1, 5, 6);
            //Executor(d2, 76, 4);
            //Console.ReadLine();

            //Multi Delegate


            //Type1

            //MyDelegate d = new MyDelegate(c.Add);
            //d += new MyDelegate(c.Subtract);
            //Executor(d, 3, 5);

            //Type2

            MyDelegate d3 = (MyDelegate)Delegate.Combine(d1, d2);
            
            Executor(d3, 3, 5);
            Console.ReadLine();



        }
        static void Executor(MyDelegate d,int input1,int input2 )
        {
            int res = d.Invoke(input1, input2);
            Console.WriteLine($"Arithematic Operation is {res}");
        }
    }
}
