﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarbageCollectorDemo
{
    class Demo : IDisposable
    {
        public void Dispose()
        {

            //Supressfinalize means donot do Automatically,we will do manually 
            GC.SuppressFinalize(this);
            GC.Collect();
        }
    }
}
