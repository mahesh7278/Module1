﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GarbageCollectorDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Allocated memory: {GC.GetTotalMemory(true)}");
            int[] ar = new int[100];
            Console.WriteLine($"Allocated memory: {GC.GetTotalMemory(false)}");

            ar = null;
            GC.Collect();
            Console.WriteLine($"Allocated memory: {GC.GetTotalMemory(true)}");

            using (Demo d = new Demo())
            {
                //use the object
                //call the other method
            }
           
            Console.ReadLine();

        }
    }
}
