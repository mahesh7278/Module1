﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionHandlingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int s = 23;
                int[] ar = new int[5];
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine("enter a number");
                    int n = Convert.ToInt32(Console.ReadLine());
                    ar[i] = s / n;

                }
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine(ar[i]);
                }
            }
            catch(FormatException f)
            {
                Console.WriteLine("you made some typing mistakes ,so type proper");
                Console.WriteLine(f.Message);
            }
            catch(IndexOutOfRangeException i)
            {
                Console.WriteLine("you are referring to an invalid number");
                Console.WriteLine(i.Message);
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("cannot divide with zero ,enter valid numbers");
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("All other exceptions handled here");
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.WriteLine("finally block executed");
            }
            Console.ReadLine();
        }
    }
}
