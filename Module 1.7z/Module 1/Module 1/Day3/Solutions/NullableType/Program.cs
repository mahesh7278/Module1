﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NullableType
{
    class Program
    {
        static void Main(string[] args)
        {
            int? mobNum=null;
            int id = 1;
            string name = "malli";
            if(mobNum.HasValue)
            {
                Console.WriteLine("it is present");
            }
            else
            {
                Console.WriteLine("it is not present");
            }

            // second one 
            int? z = 42;
            //if (z is int valueOfZ) or
            if(z.HasValue)
            {
                Console.WriteLine($"z is {z}");
            }
            else
            {
                Console.WriteLine("z does not have a value");
            }

            //Third one

            int? y = 7;
            if (y != null)
            {
                Console.WriteLine($"y is {y.Value}");
            }
            else
            {
                Console.WriteLine("y does not have a value");
            }

            //fourth

            int? c = null;

            // d = c, if c is not null, d = -1 if c is not null, print c value.
            int d = c ?? -1;
            Console.WriteLine($"d is {d}");

            //fifth

            int? n = null;

            //int m1 = n;    // Doesn't compile.
            int n2 =(int) n;

        }
    }
}
