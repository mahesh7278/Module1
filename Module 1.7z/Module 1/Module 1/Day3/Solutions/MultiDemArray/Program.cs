﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiDemArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] arr = { { 1, 657}, { 2, 565 }};
             Console.WriteLine(arr.Length);
             for(int i=0;i<2;i++)
             {
                 for(int j=0;j<2; j++)
                 {
                     Console.WriteLine("Array elements are:" + arr[i, j]);

                 }

             }
             Console.ReadLine();
           
          }
      }
  }
