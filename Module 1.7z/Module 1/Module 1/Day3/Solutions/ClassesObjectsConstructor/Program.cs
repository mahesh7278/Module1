﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesObjectsConstructor
{
    class Program
    {
        static void Main(string[] args)
        {
            // first user


            Account A = new Account(1, "malli", 10000, "Guntur");
            Console.WriteLine($"enter amount you want to Deposit");
            double amt = Convert.ToDouble(Console.ReadLine());
            A.Deposit(amt);
            Console.ReadLine();
            Console.WriteLine($"enter amount you want to withdraw");
            amt = Convert.ToDouble(Console.ReadLine());
            A.Withdraw(amt);
            Console.ReadLine();
            A.CheckBalance(amt);
            Console.ReadLine();

            // Second user


            Account B = new Account(1, "Harika", 10000, "Kakani");
            Console.WriteLine($"enter amount you want to Deposit");
            double amt1 = Convert.ToDouble(Console.ReadLine());
            B.Deposit(amt1);
            Console.ReadLine();
            Console.WriteLine($"enter amount you want to withdraw");
            amt1 = Convert.ToDouble(Console.ReadLine());
            B.Withdraw(amt1);
            Console.ReadLine();
            B.CheckBalance(amt1);
            Console.ReadLine();




        }
    }
}
