﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesObjectsConstructor
{
    class Account
    {


        //Data Members

        int accountNumber;
        string accountHolderName;
        double balance;
        string branchName;

        //Constructor with parametrs 

        public Account(int accountNum,string accountHoldName,double bal,string bn)
        {
            accountNumber = accountNum;
            accountHolderName= accountHoldName;
            balance = bal;
            branchName = bn;

        }

        // Member Functions


        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Account balance after deposit:{balance} of {accountHolderName}");

        }
        public void Withdraw(double amount)
        {
            balance = balance - amount;
            Console.WriteLine($"Account balance after withdraw:{balance} of {accountHolderName}");

        }
        public void CheckBalance(double amount)
        {
           
            Console.WriteLine($" Current Account balance :{balance} of {accountHolderName}");
           
        }
    }
}
