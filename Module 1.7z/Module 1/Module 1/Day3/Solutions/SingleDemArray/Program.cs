﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleDemArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] marks = { 12, 65, 98, 34, 86 };
            for(int i=1;i<=marks.Length-1;i++)
            {
                Console.WriteLine(" Array marks are:" + marks[i]);
            }
            Console.WriteLine("Max marks are:" + marks.Max());
            Console.WriteLine("min marks are :" + marks.Min());
            Console.WriteLine("Sum marks are :" + marks.Sum());
            Console.WriteLine("Length marks are :" + marks.Length);




        }
    }
}
