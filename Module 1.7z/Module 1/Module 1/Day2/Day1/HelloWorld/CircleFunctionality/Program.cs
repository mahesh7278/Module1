﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleFunctionality
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle c1 = new Circle();
            double d1 = c1.Cirumference(3);
            double d2 = c1.Area(5);
            Console.WriteLine("the circumference of circle is:" + d1);
            Console.WriteLine("the Area of circle is:" + d2);
            Console.ReadLine();
        }
    }
}
