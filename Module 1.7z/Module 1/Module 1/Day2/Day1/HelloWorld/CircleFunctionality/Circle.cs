﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleFunctionality
{
    class Circle
    {
        int radius;
        public double Cirumference(int radius)
        {
            double res1 = 2 * 3.14 * radius;
            return res1;

        }
        public double Area(int radius)
        {
            double res2 = 3.14 * 3.14 * radius;
            return res2;

        }
    }
}
