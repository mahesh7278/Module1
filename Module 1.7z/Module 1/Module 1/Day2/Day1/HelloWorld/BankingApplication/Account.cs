﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApplication
{
    class Account
    {
        int accountNumber = 123455;
        double balance = 1234567.678;
        string accountHolderName = "malleswari";
        public double Deposit(double amoount)
        {
            balance = balance +amoount;
            return balance;
        }
        public double Withdraw(double amount)
        {
            balance = balance - amount;
            return balance;
        }
    }
}
