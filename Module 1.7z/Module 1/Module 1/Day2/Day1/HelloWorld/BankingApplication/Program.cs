﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Account account = new Account();
            double newbalance = account.Deposit(23457.9887);
            Console.WriteLine("new balance after deposit is:" + newbalance);
            newbalance = account.Withdraw(300);
            Console.WriteLine("new balance after withdraw is:" + newbalance);
            Console.ReadLine();
               
        }
    }
}
