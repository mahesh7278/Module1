﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalDemo
{
    class Cal
    {
        public int Addition(int m,int n)
        {
            int k = m + n;
            return k;
     

        }
        
    }
}
