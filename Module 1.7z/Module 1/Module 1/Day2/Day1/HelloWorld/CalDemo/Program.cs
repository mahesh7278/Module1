﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Cal c1 = new Cal();
            int res = c1.Addition(10, 20);
            Console.WriteLine("Addtion of two numbers:" + res);
            Console.ReadLine();
        }
    }
}
