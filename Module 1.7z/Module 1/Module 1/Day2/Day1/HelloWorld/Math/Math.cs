﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Math
{
    class Math
    {
        public int Add(int num1,int num2)
        {
            int res1 = num1 + num2;
            return res1;
        }
        public int Sub(int num1,int num2)
        {
            int res2= num1 + num2;
            return res2;
        }
        public int mul(int num1,int num2)
        {
            int res3=num1 + num2;
            return res3;

        }
        public int div(int num1,int num2)
        {
            int res4 = num1 + num2;
            return res4;
        }
    }
}
