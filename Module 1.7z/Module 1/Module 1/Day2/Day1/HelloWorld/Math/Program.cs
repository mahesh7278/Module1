﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Math
{
    class Program
    {
        static void Main(string[] args)
        {
            Math m1 = new Math();
            int ad=m1.Add(1, -4);
            int sb=m1.Sub(5, 3);
            int ml=m1.mul(6, 8);
            int dv=m1.div(6, 3);
            Console.WriteLine("Addition of two numbers :" + ad);
            Console.WriteLine("subtraction of two numbers :" + sb);
            Console.WriteLine("multification of two numbers :" + ml);
            Console.WriteLine("division of two numbers :" + dv);
            Console.ReadLine();

        }
    }
}
