﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pattern
{
    class Pat
    {
        public void Pat1(int num)
        {
            for (int i = 1; i <= num; i++)
            {
                for (int j = 1; j <= num; j++)

                {
                    if (i >= j)
                    {

                        Console.Write("*");
                    }
                }

                Console.WriteLine();
            }
        }

       public void Pat2(int num1)
        {
            int star = 1, space = 4;
            for(int i=1;i<=num1;i++)
            {
               for(int j=1;j<=space;j++)
                {
                    Console.Write("  ");
                }
               for(int k=1;k<=star;k++)
                {
                    Console.Write("*  ");
            
                }
                star++;
                space--;
                Console.WriteLine();
            }
        }

    }
}
