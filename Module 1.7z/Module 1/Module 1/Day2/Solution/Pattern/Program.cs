﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pattern
{
    class Program
    {
        static void Main(string[] args)
        {
            Pat p1 = new Pat();
            p1.Pat1(5);
           
            p1.Pat2(5);
            Console.ReadLine();
        }
    }
}
