﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTypesVarify
{
    class Program
    {
        static void Main(string[] args)
        {
            int k= 2147483647;
            Console.WriteLine(k);

            long m = 9223372036854775807;
            Console.WriteLine(m);

            sbyte b = 126;
            Console.WriteLine(b);

            char ch = 'o';
            Console.WriteLine(ch);

            Console.ReadLine();
            



        }
    }
}
