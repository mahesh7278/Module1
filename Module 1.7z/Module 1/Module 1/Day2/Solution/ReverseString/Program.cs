﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReverseString
{
    class Program
    {
        static void Main(string[] args)
        {


            string str = "Harika";
            string str1 = "";
              
            for (int i = str.Length - 1; i >= 0; i--)
            {
                str1 = str1 + str[i];

            }
            Console.WriteLine("Reverse string is:" + str1);
            Console.ReadLine();

        }
    }
}
