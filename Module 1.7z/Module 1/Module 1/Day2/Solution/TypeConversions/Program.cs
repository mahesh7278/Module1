﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeConversions
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 125;
            double b = a; //Implicit
            Console.WriteLine(b);


            double k = 123.45;
            int m = (int)k;//Explicit
            Console.WriteLine(m);
            
            
            //boxing

            int i = 1234;
            object o = i;
            Console.WriteLine(o);

            //unboxing

            int j = (int)o;
            Console.WriteLine(j);
             

        }
    }
}
