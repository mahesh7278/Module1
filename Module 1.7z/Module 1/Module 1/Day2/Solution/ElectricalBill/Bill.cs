﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectricalBill
{
    class Bill
    {
        public void Billing(double unit)
        {
            
            if (unit < 100)
            {
                unit = unit * 0.4+ 50;
                

                Console.WriteLine("the current bill is :" + unit + " per unit");

            }
            else if ((unit > 100) && (unit < 300))
            {
                unit = unit * 0.6 + 50;
                Console.WriteLine("the current bill is :" + unit + " per unit");

            }
            else if (unit > 300)
            {
                unit = unit * 0.6+50;
                Console.WriteLine("the current bill is :" + unit + " per unit");
            }
            else if (unit > 400)
            {
                double fine = 15 / 100;
                unit = unit * fine+50;
                Console.WriteLine("the current bill is :"+ unit +" per unit");


            }

            
        }
        }
}
