﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ElectricalBill
{
    class Program
    {
        static void Main(string[] args)
        {
            Bill b = new Bill();
            b.Billing(290);
            b.Billing(430);
            b.Billing(60);
            Console.ReadLine();
            

        }
    }
}
