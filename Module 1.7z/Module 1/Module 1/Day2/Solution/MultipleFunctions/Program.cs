﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultipleFunctions
{
    class Program
    {
        static void Main(string[] args)
        {
            UniqueFunctions u = new UniqueFunctions();

            //factorial
            u.Fact(5);
           

            //positive or negative or zero
            u.Checking(5);
            u.Checking(-7);
            u.Checking(0);


            //A Rise B

            u.Rise(2, 4);

           
            

            Console.ReadLine();

        }

    }
}
