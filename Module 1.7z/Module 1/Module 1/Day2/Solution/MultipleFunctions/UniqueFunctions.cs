﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultipleFunctions
{
    class UniqueFunctions
    {

        // factorial
        public void Fact(int num)
        {
            int fact = 1;
            for (int i = 1; i <= num; i++)
            {
                
                fact = fact * i;
               
            }
            Console.WriteLine(fact);

        }

        //positive or negative or zero
          
        public void Checking(int num1)
        {
            if(num1>0)
            {
                Console.WriteLine("Given Number is positive");
            }
           else  if (num1 < 0)
            {
                Console.WriteLine("Given Number is Negative");
            }
            else 
            {
                Console.WriteLine("Given Number zero");
            }

        }


        //A rise B
         
        public void Rise(double a,double b)
        {
            double res = Math.Pow(a, b);
            Console.WriteLine(res);

        }

       
       
    }
}
