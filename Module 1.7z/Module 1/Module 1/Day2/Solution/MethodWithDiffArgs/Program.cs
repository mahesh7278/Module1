﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodWithDiffArgs
{
    class Program
    {
        static void Main(string[] args)
        {
            int square = 0, cube1 = 0;
            Parameters p = new Parameters();
            p.CubeSq(5, ref square, ref cube1);
            Console.WriteLine("square is" + square);
            Console.WriteLine("cube is" + cube1);


            int square1, cube2;
            p.SqCube(7, out square1, out cube2);
            Console.WriteLine("square is" + square1);
            Console.WriteLine("cube is" + cube2);


              
            Console.WriteLine("Adding of numbers are" + p.Add(10,32));
            Console.WriteLine("Adding of numbers are" + p.Add(4,76));
            Console.WriteLine("Adding of numbers are" + p.Add(10, 32,9875,788));
            Console.WriteLine("Adding of numbers are" + p.Add(10, 32,876,78,8775,98776));



            Console.ReadLine();
            


        }
    }
}
