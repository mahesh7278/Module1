﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodWithDiffArgs
{
    class Parameters
    {


        //ref
       public void CubeSq(int num,ref int sq,ref int cube)
        {
            sq = num * num;
            cube = num * num * num;

        }


        //out
        public void SqCube(int num1,out int sq1,out int cube1)
        {
            sq1 = num1 * num1;
            cube1 = num1 * num1 * num1;

        }




        //params
        public int Add(params int[] a)
        {
            int sum = 0;
            for(int i=0;i<a.Length;i++)
            {
                sum = sum + a[i];
            }
            return sum;
        }
    }
}
