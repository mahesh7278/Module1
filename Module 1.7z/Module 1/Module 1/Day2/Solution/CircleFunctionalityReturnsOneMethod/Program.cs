﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleFunctionalityReturnsOneMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            
            CalCirfiCir c1 = new CalCirfiCir();
            double cirfe, circle;
            c1.Circf(5, out cirfe, out circle);
            Console.WriteLine("Circumference of circle is" + cirfe);
            Console.WriteLine("cube of circle is" + circle);
            Console.ReadLine();

        }
    }
}
