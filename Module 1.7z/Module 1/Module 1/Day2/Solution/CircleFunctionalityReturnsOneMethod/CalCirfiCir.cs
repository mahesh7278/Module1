﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleFunctionalityReturnsOneMethod
{
    class CalCirfiCir
    {
        double pi = 3.14;
        public void Circf(double radius, out double cir, out double cf)
        {
            cir = 2*pi *radius;
            cf=pi*pi*radius;
            
        }

    }
}
