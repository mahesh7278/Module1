﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.IO;
using System.Collections;

namespace OtherDemos
{
    class Program:IEnumerable
    {
        static void Main(string[] args)
        {
            /*
            int no = 10;
            int res = no.Add(5);
            Console.WriteLine(res);

            string username = "Malleswari";
            string userGreeting = username.Greet("Good Morning");
            Console.WriteLine(userGreeting);*/

            /***Overriding
            Employee emp = new Employee();
            emp.DoJob();


            Person p=new Employee();
            p.DoJob();****/

            //File Handling-File system info properties
            //Drive Directories-Files


            //DriveInfo[] driveInfos = DriveInfo.GetDrives();
            //foreach (DriveInfo dinfo in driveInfos)
            //{
            //    //Console.WriteLine("DriveName:" + dinfo.Name + "Volumelabel:"+dinfo.VolumeLabel
            //    //+"DriveType:" + dinfo.DriveType);

            //    Console.WriteLine("\n Drive Name:"+dinfo.Name);

            //    DirectoryInfo directoryInfo = new DirectoryInfo(dinfo.Name);
            //    DirectoryInfo[] dirs= directoryInfo.GetDirectories();
            //    Console.WriteLine("\n Folder info");


            //    foreach (DirectoryInfo item in dirs)
            //    {
            //        Console.WriteLine(item.FullName);
            //        Console.WriteLine(item.TotalFreeSpace);
            //    }
            //    FileInfo[] file = directoryInfo.GetFiles();
            //    Console.WriteLine("\n Folder info");


            //    foreach (FileInfo f in file)
            //    {
            //        Console.WriteLine(f.Length);
            //        Console.WriteLine(f.LastAccessTime);
                   
            //    }
                
            //}


            foreach (var item in NumberRangeGenerator.GenerateNumber(13,8))
            {
                Console.WriteLine(item);
            }
            //Mycollection obj= new Mycollection();

            //foreach (var item in obj)
            //{
            //    Console.WriteLine(item);
            //}
            Console.ReadKey();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
}
