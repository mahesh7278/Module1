﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OtherDemos
{
    class Person
    {
        public virtual void DoJob()
        {
            Console.WriteLine("Person is doing his job....");
        }
    }
    class Employee:Person
    {
        public override void DoJob()
        {
            Console.WriteLine("Employee is doing his job....");
        }
    }

}
