﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OtherDemos
{
   static class StringExtenstion
    {
        public static string Greet(this string username,string str)
        {
            return username + str; 
        }
    }
}
