﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace OtherDemos
{
    ////Traditional 
    class Mycollection : IEnumerable
    {
        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }
    }
    class NumberRangeGenerator
    {
        static public IEnumerable GenerateNumber(int maxNum,int minNum)
        {
            //int[] arr = new int[(maxNum - minNum) + 1];
            for (int i =minNum; i <= maxNum; i++)
            {
                yield return i;
            }
            //return arr;
        }
    }
}
