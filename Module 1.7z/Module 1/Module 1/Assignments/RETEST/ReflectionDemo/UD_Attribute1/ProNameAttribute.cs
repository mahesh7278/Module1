﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UD_Attribute1
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]

    public class ProNameAttribute:Attribute
    {

        public string ProjectName
        {
            get; set;
        }
        public string DeveloperName
        {
            get; set;
        }
        public ProNameAttribute(string prName, string devName)
        {
            ProjectName = prName;
            DeveloperName = devName;
        }
                        

    }
}
