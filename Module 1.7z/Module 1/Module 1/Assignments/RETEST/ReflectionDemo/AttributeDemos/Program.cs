﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using EMS_Entity;
using UD_Attribute;
using System.Reflection;

namespace AttributeDemos
{
    class Program
    {
        //[Obsolete("This is too old..use instead of M2",true)]
        //static void m1()
        //{
        //    Console.WriteLine("this is functionality to send indian post email");
        //}
        //static void m2()
        //{
        //    Console.WriteLine("this is functionality to send email");
        //}

        static void Main(string[] args)
        {
            //m2();

            //dynamic path
            //Assembly ass = Assembly.LoadFrom("gfh/EMS_Entity.dll");
            //Type t = ass.GetType("EMS_Entity.Employee"); 
            //DeveloperInfoAttribute dia= (DeveloperInfoAttribute)Attribute.GetCustomAttribute(t,typeof(DeveloperInfoAttribute));

            //Static way

            DeveloperInfoAttribute dia = (DeveloperInfoAttribute)Attribute.GetCustomAttribute(typeof(Employee),
                                          typeof(DeveloperInfoAttribute));
            Console.WriteLine(dia.DeveloperName);
            Console.ReadKey();



        }
    }
}
