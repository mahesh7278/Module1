﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Reflection;
using UD_Attribute1;

namespace AttributeDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly ass = Assembly.LoadFrom(@"C:\Assignments\RETEST\ReflectionDemo\EMS_Entity\bin\Debug\EMS_Entity.dll");
            Type t = ass.GetType("EMS_Entity.Employee");
            ProNameAttribute dia = (ProNameAttribute)Attribute.GetCustomAttribute(t, typeof(ProNameAttribute));

            Console.WriteLine(dia.ProjectName);
            Console.WriteLine(dia.DeveloperName); 
            Console.ReadKey();
        }
    }
}
