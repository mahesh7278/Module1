﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UD_Attribute1;

namespace EMS_Entity
{
    [ProNameAttribute("Manager","malleswari")]
    public class Manager
    {

    }
}
