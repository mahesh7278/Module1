﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UD_Attribute1;

namespace EMS_Entity
{
    [ProNameAttribute("sd", "sandeepa")]
    public class Employee
    {
        
        public void m1()
        {

        }

    }
}
