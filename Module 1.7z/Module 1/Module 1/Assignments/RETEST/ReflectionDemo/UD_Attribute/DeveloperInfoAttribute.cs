﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace UD_Attribute
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method ,AllowMultiple =true)]
    public class DeveloperInfoAttribute:Attribute
    {
        public string DeveloperName
        {
            get;set;
        }

        public DeveloperInfoAttribute(string devName)
        {
            DeveloperName = devName;
        }
    }
}
