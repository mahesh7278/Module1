﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionTest
{
    class Program
    {
        static void Main(string[] args)
        {
            //Extract Metadata of Assembly -Reflectiondemo.dll,DelegteDemo.exe
            Console.WriteLine("Enter Path");
            string pathOfAss = Console.ReadLine();
            Assembly asm = Assembly.LoadFrom(pathOfAss);
            Type[] types = asm.GetTypes();
            foreach  (Type t in  types)
            {
                Console.WriteLine(t.FullName);
                MethodInfo[] methodInfos= t.GetMethods();//Methods
                Console.WriteLine("methods from"+t.Name);

                foreach (MethodInfo mi in methodInfos)
                {
                    ParameterInfo[] parameterInfos = mi.GetParameters();
                    foreach (ParameterInfo ki in parameterInfos)
                    {
                        Console.WriteLine(ki.ToString());
                    }
                    Console.WriteLine(mi.ReturnType.Name + "" + mi.Name + "( " + " ) ");
                    Console.WriteLine(mi.ToString());
                }

                Console.WriteLine("properties from" + t.Name);
                PropertyInfo[] props = t.GetProperties();//Properties
                foreach (PropertyInfo pi in props)
                {

                    Console.WriteLine(pi.ToString());
                }

                Console.WriteLine("field from" + t.Name);
                FieldInfo[] fiss = t.GetFields();//Properties
                foreach (FieldInfo f in fiss)
                {

                    Console.WriteLine(f.ToString());
                }
            }
            Console.ReadLine();
        }
    }
}
