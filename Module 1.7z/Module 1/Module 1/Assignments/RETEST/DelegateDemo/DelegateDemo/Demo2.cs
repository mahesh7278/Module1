﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    class Calc
    {
        public double Add(double d1, double d2)
        {
            return d1 + d2;
        }

        public double Sub(double d1, double d2)
        {
           return d1 - d2;
        }
    }
    class Demo2
    {

        //**Define Delegate

        delegate double CalcDemodelegate(double d1, double d2);
        static void Main(string[] args)
        {
            //Calc c = new Calc();
            ////**Create instance of delegate and it hold multiple 

            //CalcDemodelegate del = new CalcDemodelegate(c.Add);
            //del+= new CalcDemodelegate(c.Sub);

            ////**Invoking

            //del(7.8, 9.8);


            //**By uisng Inbuilt Delegate


            //CalcDemodelegate del1 = new CalcDemodelegate(c.Add);
            //CalcDemodelegate del2 = new CalcDemodelegate(c.Add);
            //CalcDemodelegate mdel = (CalcDemodelegate)MulticastDelegate.Combine(del1, del2);
            //mdel(8.7, 9.6);
            //CalcDemodelegate ndel = (CalcDemodelegate)MulticastDelegate.Remove(mdel, del1);
            //ndel(6.8, 9.8);

            //** passing Runtime 
            //double d1 = 7.8, d2 = 9.7;
            //DoTask(c.Add, d1, d2);

            double d1 = 123.34, d2 = 390.34;
            //**Anonymous delegate

            DoTask(delegate (double a1, double a2) { return a1 + a2; }, d1, d2);

            //***Lamda Expression 

            //**Single line**//
            DoTask((a1, a2) =>  a1 + a2, d1, d2);

            //**Multiple line**//
            DoTask((a1, a2) => { Console.WriteLine("Hello"); return a1 + a2; }, d1, d2);




        }


        static void DoTask(CalcDemodelegate task, double d1, double d2)
        {
            task(d1, d2);
        }
    }
}
