﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    public delegate void Mydel1();
    class Program
    {
        static void Abc()
        {
            Console.WriteLine("hello this is inbulit delegate");
        }

        static void Main(string[] args)
        {
            //***Defineing delegate inbuilt Delegate

            //Action ad1 = new Action(Abc);
            //ad1();

            Mydel1 d1 = new Mydel1(Abc);
            d1();
            Console.ReadLine();

        }
    }
}
