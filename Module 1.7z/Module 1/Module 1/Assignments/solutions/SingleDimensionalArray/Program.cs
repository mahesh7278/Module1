﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleDimensionalArray
{
    class Program
    {
       

        static void Main(string[] args)
        {
            Console.WriteLine("enter number");
            int n = Convert.ToInt32(Console.ReadLine());
            string[] a = new string[n];
            Console.WriteLine("Enter City Name");
            for (int i = 0; i <n; i++)
            {
                
                a[i] =Console.ReadLine();
            }
            Console.WriteLine("The City names are");
            foreach(string arr in a)
            {
                Console.Write("\t"+ arr);
            }
        }
    }
}
