﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwoDimensionalArray
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number of rows");
            int m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter number of coloums");
            int n = Convert.ToInt32(Console.ReadLine());
            int[,] a = new int[m,n] ;
            int i, j;
            for (i = 0; i <m; i++)
            {

                for (j = 0; j <n; j++)
                {
                    
                    Console.WriteLine("element - [{0},{1}] : ", i, j);
                    a[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.Write("\nThe matrix is : \n");
            for (i = 0; i < m; i++)
            {
                Console.Write("\n");
                for (j = 0; j < n; j++)
                {
                    Console.Write( "\t"+ a[i, j] );
                }
            }
        }
    }
}
