﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDemo
{
    class Product
    {
        double payable;
        public void EnterD()
        {
            //Boxing

            Console.WriteLine("Enter product Id");
            int PId = Convert.ToInt32(Console.ReadLine());
            object ProductId = PId;
            Console.WriteLine("Enter product Name");
            string pName = Console.ReadLine();
            object ProductName = pName;
            Console.WriteLine("Enter price");
            int price = Convert.ToInt32(Console.ReadLine());
            object Price =price;
            Console.WriteLine("Enter Quantity");
            byte qty = Convert.ToByte(Console.ReadLine());
            object Qty = qty;

            //UnBoxing
            int ProductID = (int)ProductId;
            string PName = (string)ProductName;
            int prc = (int)Price;
            byte quality = (byte)Qty;
            payable = prc * quality;

            Console.WriteLine("Product Details");
            Console.WriteLine("Product ID:" + ProductID);
            Console.WriteLine("Product Name:" + PName);
            Console.WriteLine("Product Price:" + prc);
            Console.WriteLine("Product Quantity:" + quality);
            Console.WriteLine("Amount Payable:"+payable);
        }
    }
}
