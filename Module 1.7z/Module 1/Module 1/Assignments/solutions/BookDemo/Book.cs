﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookDemo
{
    class Book
    {
        public void Details()
        {
            string[,] myArr = new string[2, 4]{
                                
                                 { " Book Title","Author","Price","Publisher"},
                                 {" FAB15"," SRK GANG"," 2349"," SRK Foundation" }};
           
            foreach (string s in myArr)
            {
                Console.Write(s);
            }
            Console.WriteLine("\n");

        }
    }
}
