﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Book b = new Book();
            b.Details();
            Console.ReadLine();
        }
    }
}
