﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierInstance
{
    class SupplierTest
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public long PhNum{ get; set; }
        public string Email { get; set; }
        public SupplierTest(int Id, string Name, string City, long PhNum, string Email)
        {
            this.Id = Id;
            this.Name = Name;
            this.City = City;
            this.PhNum = PhNum;
            this.Email = Email;
        }
        public void Display()
        {
            Console.WriteLine("Supplier Id is:"+ Id);
            Console.WriteLine("Supplier Name is:" + Name);
            Console.WriteLine("Supplier city is:" + City);
            Console.WriteLine("Supplier Phnum is:" + PhNum);
            Console.WriteLine("Supplier email is:" + Email);

        }

    }
}
