﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BirdDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            BirdCls b = new BirdCls("Eagle", 200.00);
            b.fly();
            b.fly(300);


        }
    }
}
