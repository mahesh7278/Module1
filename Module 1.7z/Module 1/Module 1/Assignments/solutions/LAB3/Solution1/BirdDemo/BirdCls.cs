﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BirdDemo
{
    class BirdCls
    {
        
            public string Name;
            public double Maxheight;

            public BirdCls()  //Default Constructor   
            {    

                 // TODO: Add constructor logic here   
            } 

            public BirdCls(string birdname, double max_ht) //Overloaded Constructor  
            {
                this.Name = birdname;
                this.Maxheight = max_ht;
            } 


           public void fly()

            {
                Console.WriteLine(this.Name + " is flying at altitude "+this.Maxheight);
            }

            public void fly(double AtHeight)
            {
                if (AtHeight <= this.Maxheight)
                {
                    Console.WriteLine(this.Name + " flying at " + AtHeight);
                }
                else 
                    {
                    Console.WriteLine(this.Name+" cannot fly at this height");
                  }
            
        }
    }
}
