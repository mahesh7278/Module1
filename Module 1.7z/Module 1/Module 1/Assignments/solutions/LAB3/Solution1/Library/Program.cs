﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Participant p = new Participant();
                Participant p1 = new Participant();
                Console.WriteLine("enter empid");
                int empid = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("enter empName");
                string empname = Console.ReadLine();

                Console.WriteLine("enter Foundation marks");
                int fm = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("enter WebBasic marks");
                int wbm = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("enter DotNet marks");
                int dnm = Convert.ToInt32(Console.ReadLine());
                p1.CalTotalMarks();
                p1.CalPercentage();
                Console.WriteLine("EmpId {0},Name {1},FoundationMarks {2},DotNetMarks {3},WebBaiscMarks {4}",
                       p.EmpID, p.EmpName, p.FoundationMarks, p.DotNetMarks, p.WebBasicMarks);
                //p1.Display();

                
            }

        
           catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
        
    }
}
