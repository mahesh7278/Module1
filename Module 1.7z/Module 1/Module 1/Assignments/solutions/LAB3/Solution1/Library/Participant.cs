﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class Participant
    {
        private int empId;
        private string name;
        static string companyName;
        private int foundationMarks, webBasicMarks, dotNetMarks, obtainedMarks;
        public double percentage;
        static int totalMarks = 300;
        public int EmpID { get; set; }
        public string EmpName
        {
            get; set;
        }
        public int FoundationMarks { get; set; }
        public int WebBasicMarks
        {
            get
            {
                return webBasicMarks;
            }
            set
            {
                if ((value > 0) && (value < 100))
                {
                    webBasicMarks = value;
                }
                else
                {
                    webBasicMarks = 0;
                }
            }
        }
        public int DotNetMarks { get 
            {
                return DotNetMarks;
            }
            set
            {

                if ((value > 0) && (value < 100))
                    {
                        DotNetMarks = value;
                    }
                    else
                    {
                    Console.WriteLine("enter marks between 0 to 100 only");
                    }
                }
            }
        public int ObtainedMarks
        {
            get
            {
                return ObtainedMarks;
            }
            set
            {
                if ((value > 0) && (value < 100))
                {
                    ObtainedMarks = value;
                }
                else
                {
                    Console.WriteLine("enter marks between 0 to 100 only");
                }
            }
        }
        public double Percentage { get; set; }
        static Participant()
        {
            companyName= "Corporate Unniversity";
        }
        public Participant()
        {
            Console.WriteLine("Default Constructor");
        }
        public Participant(int fdm,int wbm,int dnm)
        {
            
            this.FoundationMarks = fdm;
            this.WebBasicMarks = wbm;
            this.DotNetMarks = dnm;
            
        }
        
        public void CalTotalMarks()
        {
            ObtainedMarks = FoundationMarks + WebBasicMarks + DotNetMarks;
            Console.WriteLine("Total marks are:"+ObtainedMarks);
            
        }
        public void  CalPercentage()
        {
            double per = (ObtainedMarks*100/totalMarks);
            //double res = per * 100;
            Console.WriteLine("Percentage is:"+per);
        }
       
            
         
        
    }
}
