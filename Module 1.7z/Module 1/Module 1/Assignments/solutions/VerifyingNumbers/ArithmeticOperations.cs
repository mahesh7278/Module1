﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryProject
{
    class ArithmeticOperations
    {
        public void AriOp()
        {
            Console.WriteLine(" enter Numbers");
            int num = Convert.ToInt32(Console.ReadLine());
            switch (num)
            {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                       Console.WriteLine(" Entered number is valid");
                       break;
                default:
                       Console.WriteLine(" Entered number is not valid");
                       break;




            }
        }

    }
}
