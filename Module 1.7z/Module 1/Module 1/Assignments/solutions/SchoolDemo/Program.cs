﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student(19, "surekha",21,'f', "08-08-1997" ,"3-234,mumbai",68);
            Student s2 = new Student(32, "suji", 21, 'f', "03-04-1997", "45-34 ,mumbai", 71);
            Student s3 = new Student(144, "sukke", 21, 'f', "07-08-1997", "34-56 ,mumbai", 80);
            s.DisplayDetails();
            s2.DisplayDetails();
            s3.DisplayDetails();
            Console.ReadLine();

        }
    }
}
