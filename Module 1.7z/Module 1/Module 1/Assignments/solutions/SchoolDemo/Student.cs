﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolDemo
{
    class Student
    {
        public int RollNum
        {
            get; set;
        }
        public string StdName
        {
            get; set;
        }
        public byte Age
        {
            get; set;
        }
        public char Gender
        {
            get; set;
        }
        public string DateOfBirth
        {
            get; set;
        }
        public string Address
        {
            get; set;
        }
        public float Percentage
        {
            get; set;
        }
        public Student(int RollNum, string StdName, byte Age, char Gender,
            string DateOfBirth, string Address, float Percentage)
        {
            this.RollNum = RollNum;
            this.StdName = StdName;
            this.Age = Age;
            this.Gender = Gender;
            this.DateOfBirth = DateOfBirth;
            this.Address = Address;
            this.Percentage = Percentage;
        }
        public void DisplayDetails()
        {
            Console.WriteLine(RollNum);
            Console.WriteLine(StdName);
            Console.WriteLine(Age);
            Console.WriteLine(Gender);
            Console.WriteLine(DateOfBirth);
            Console.WriteLine(Address);
            Console.WriteLine(Percentage);


        }
    }
    
}
