﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureDemo
{
    struct StoreInfo
    {

        public void Smp(int Number)
        {
            Console.WriteLine("Select 1 for Square of number");
            Console.WriteLine("select 2 for cube of the number");
            Console.WriteLine("Enter Number");
            int a=Convert.ToInt32(Console.ReadLine());
            switch (a)
            {
                case 1:
                    int res = Number * Number;
                    Console.WriteLine("Square of the number is"+res);
                    break;
                case 2:
                    int res1 = Number * Number* Number;
                    Console.WriteLine("Cube of the number is" + res1);
                    break;

               default:
                    Console.WriteLine("please Enter 1 or 2 only");
                    break;


            }
        }
    }
}
