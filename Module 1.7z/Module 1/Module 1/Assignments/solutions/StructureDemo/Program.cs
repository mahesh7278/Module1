﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructureDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            StoreInfo s = new StoreInfo();
            Console.WriteLine("Enter  Number");
            int Num = Convert.ToInt32(Console.ReadLine());
            s.Smp(Num);
            Console.ReadLine();
        }
    }
}
