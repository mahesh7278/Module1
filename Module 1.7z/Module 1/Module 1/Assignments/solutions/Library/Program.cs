﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class Program
    {
        static void Main(string[] args)
        {
            ArithematicOp op = new ArithematicOp();
            Console.WriteLine(" enter Number A");
            int A = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(" enter Number B");
            int B = Convert.ToInt32(Console.ReadLine());
            op.Addition(A, B);
            op.Subtract(A, B);
            op.Multify(A, B);
            op.Division(A, B);
            op.Modulo(A, B);
            Console.ReadLine();

        }
    }
}
