﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Add, Subtract, Multiply, Divide and Modulus on two numbers of integer type, and double type
namespace Library
{
    class ArithematicOp
    {

        public void Addition(int a,double b)
        {
            double res = a + b;
            Console.WriteLine("Adding two numbers are :" + res);

        }
        public void Subtract(int a, double b)
        {
            double res = a - b;
            Console.WriteLine("Subtract two numbers are :" + res);

        }
        public void Multify(int a, double b)
        {
            double res = a * b;
            Console.WriteLine("multify two numbers are :" + res);

        }
        public void Division(int a, double b)
        {
            double res = a / b;
            Console.WriteLine("Divide two numbers are :" + res);

        }
        public void Modulo(int a, double b)
        {
            double res = a % b;
            Console.WriteLine("Modulo two numbers are :" + res);

        }
    }
}
