﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectAndMethodDemo
{
    class Program
    {
        static void Main(string[] args)
        {


            //Intializing Datamembers without using Constructors
            //type1

            Student s = new Student { StdId = 1122, StdName = "mali", Mark = 324 };

            Console.WriteLine(s.StdId);
            Console.WriteLine(s.StdName);
            Console.WriteLine(s.Mark);
            
            //type2

            Student s1 = new Student() { StdId = 1125, StdName = "harika", Mark = 3245 };

            Console.WriteLine(s1.StdId);
            Console.WriteLine(s1.StdName);
            Console.WriteLine(s1.Mark);

            //type3

            var s2 = new Student()
            {
                StdId = 1125,
                StdName = "vidya",
                Mark = 456
            };
            Console.WriteLine(s2.StdId);
            Console.WriteLine(s2.StdName);
            Console.WriteLine(s2.Mark);



            //Indexer 

            IndexerEmail i = new IndexerEmail();
            i[0] = "malli2gmail.com";
            i[1] = "harika@gmail.com";
            i[2] = "sista@hotmail.com";
            Console.WriteLine(i[0]);
            Console.WriteLine(i[1]);
            Console.WriteLine(i[2]);
            Console.ReadLine();
        }
    }
}
