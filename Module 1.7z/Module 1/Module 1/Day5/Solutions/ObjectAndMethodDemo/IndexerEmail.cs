﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectAndMethodDemo
{
    class IndexerEmail
    {
        private string[] email = new string[100];
        public string this[int index]
        {
            get { return email[index]; }
            set
            {
                email[index] = value;
            }
        }
    }
}
