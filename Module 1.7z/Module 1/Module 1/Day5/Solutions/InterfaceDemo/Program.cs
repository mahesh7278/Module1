﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle c = new Circle();
            c.ApplyColour("yellow");
            c.Draw();
            c.RemoveColour();
            Console.ReadLine();
        }
    }
}
