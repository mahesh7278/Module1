﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo
{
    abstract class Shape
    {
        public abstract void Draw();
    }
    interface IColour
    {
        void ApplyColour(string colorname);
        void RemoveColour();
    }
 
    class Circle : Shape, IColour
    {
        public override void Draw()
        {
            Console.WriteLine("Drawing circle");
        }
        public void ApplyColour(string colorname)
        {
            Console.WriteLine("Applying color to circle:"+colorname);
        }
        public void RemoveColour()
        {
            Console.WriteLine("colour is removed successfully");
        }

      
    }
}
