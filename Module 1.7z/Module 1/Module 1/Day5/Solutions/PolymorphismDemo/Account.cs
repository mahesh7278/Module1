﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    abstract class Account
    {
       
       
        public int AccountNumber
        {
            get;set;
        }
        public double Balance
        {
            get;set;
        }
        public string AccountHolderName
        {
            get;set;
        }
        public virtual void Accept()
        {
            Console.WriteLine("enter AccountNUmber");
            this.AccountNumber = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter AccountHolder name");
            this.AccountHolderName = Console.ReadLine();
            Console.WriteLine("enter balance");
            this.Balance = Convert.ToDouble(Console.ReadLine());
        }
        public void Deposit(double amoount)
        {
            this.Balance +=  amoount;
            Console.WriteLine("Amount withdraw succesfully:"+Balance);
        }
        public void Withdraw(double amount)
        {
            if (this.Balance > amount)
            {

                this.Balance -= amount;
                Console.WriteLine("Amount deposit succesfully:"+Balance);
            }
            throw new Exception("Insufficient Successfully");
        }
        public virtual void print()
        {
            Console.WriteLine("Account number is:"+AccountNumber);
            Console.WriteLine("Account name is:" + AccountHolderName);
            Console.WriteLine("Account balance is:" + Balance);
        }
    }
    class CurrentAccount:Account
    {
        public double OverDraftLimit
        {
            get; set;
        }
        public int TransactionLimit
        {
            get; set;
        }
        public override void print()
        {
            base.print();
            Console.WriteLine($"override limit :{OverDraftLimit}");
            Console.WriteLine($"transaction limit :{TransactionLimit}");
        }
        public override void Accept()
        {
            base.Accept();
            Console.WriteLine("Enter overdraft limit");
            this.OverDraftLimit = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("enter Transaction limit");
            this.TransactionLimit = Convert.ToInt32(Console.ReadLine());

        }
    }
    class SavingAccount:Account
    {
        public bool Issalary
        {
            get;set;
        }
        public override void Accept()
        {
            base.Accept();
            Console.WriteLine("it is a salary account (Y/N)");
            string input = Console.ReadLine();
            this.Issalary = (input ==" Y") ? true: false;

        }
        public override void print()
        {
            base.print();
            Console.WriteLine($"salary Account :{Issalary}");
        }
    }
    class FixedAccount:Account
    {
        public int Duration { get; set; }
        public double InterstRate { get; set; }
        public override void Accept()
        {
            base.Accept();
            Console.WriteLine("enter Transaction limit");
            this.Duration = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter overdraft limit");
            this.InterstRate = Convert.ToDouble(Console.ReadLine());
        }
        public override void print()
        {
            base.print();
            Console.WriteLine("Deposit Duration is:"+Duration);
            Console.WriteLine("Interst rate is:"+InterstRate);
        }
    }
}
