﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //ArithematicOp op = new ArithematicOp();
            //op.Addition(2, 6);
            //int res=op.Addition(5, 8, 9);
            //Console.WriteLine(res);
            //string res1=op.Subtraction("mal", "li");
            //Console.WriteLine(res1);
            //int res2=op.Subtraction(8, 0);
            //Console.WriteLine(res2);
            //string re=op.Subtraction(3, "hello");
            //Console.WriteLine(re);



            //CurrentAccount ca = new CurrentAccount();
            //ca.AccountNumber = 123;
            //ca.AccountHolderName = "malli";
            //ca.Balance = 12345;
            //ca.OverDraftLimit = 2100;
            //ca.TransactionLimit = 233;
            //ca.print();



            //Run time Polymorphism
            Account account;
            Console.WriteLine("what type of account do you want");
            Console.WriteLine("1)Saving \n2)Current \n3)Fixed ");
            int choice = Convert.ToInt32(Console.ReadLine());
            if(choice==1)
            {
                account = new SavingAccount();

            }
            else if(choice==2)
            {
                account =new  CurrentAccount();
            }
            else
            {
                account=new FixedAccount();
            }
            account.Accept();
            account.print();

            Console.ReadLine();




        }
    }
}
