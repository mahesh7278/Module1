﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    class ArithematicOp
    {
        public void Addition(int a, int b)
        {
            int res = a + b;
            Console.WriteLine("the addition is:" + res);

        }
        public int Addition(int a, int b, int c)
        {
            int res = a + b + c;
            return res;

        }
        public string Subtraction(string a, string b)
        {
            return a + b;
        }
        public int Subtraction(int a, int b)
        {
            return a + b;
        }
        public string Subtraction(int a, string b)
        {
            return a + b;
        }
    }
}
