﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtenstionMethod
{
    static class NewString
    {
        public static void Print(this string str)
        {
            int count =1, l=0;
            while ( l <= str.Length-1 )
            {

                if (str[l]== ' ' ||  str[l] == '\n' || str[l] == '\t')
                {
                    count++;
                    
                }
                l++;
            }
            Console.WriteLine(count);
        }
    }
}
