﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToString
{
    class Person
    {
        public string FirstName
        {
            get;set;
        }
        public string LastName
        {
            get; set;
        }

        public Person(string fn,string ln)
        {
            FirstName = fn;
            LastName = ln;
        }
        public override string ToString()
        {
            base.ToString();
            return FirstName + "  " + LastName;
           

        }
    }
}
