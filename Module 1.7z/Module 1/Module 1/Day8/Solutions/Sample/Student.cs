﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Sample
{
    [Author("CGemini")]
    [Author("FAB15", Description = "Creating constructor", Modification = "15/10/2019")]
    [Author("Gang", Description = "bug fix", Modification = "15/10/2019")]

    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Marks{ get; set; }
        [Author("FAB15",Description ="Intializing with values",Modification ="15/10/2019")]
        public Student()
        {


        }
        public Student(int id,string name,int marks)
        {
            this.Id = id;
            this.Name = name;
            this.Marks = marks;
        }
        [Author("TCS",Modification ="15/10/2019")]
        public void Show()
        {
            Console.WriteLine("Name:"+Name);
            Console.WriteLine("Id:" + Id);
            Console.WriteLine("Mark:" + Marks);
        }
    }
}
