﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample
{
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Constructor|AttributeTargets.Class,AllowMultiple=true)]
    public class AuthorAttribute:Attribute
    {
        private string name;
        private string description;
        private string modification;
        public AuthorAttribute(string name)
        {
            this.name = name;
        }
        public string Name
        {
            get { return name; }
        }
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        public string Modification
        {
            get { return modification; }
            set { modification = value; }
        }
    }
}
