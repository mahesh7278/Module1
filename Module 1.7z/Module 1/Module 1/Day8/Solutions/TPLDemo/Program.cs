﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPLDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Show(22, "suresh", "M", "FC");
            Show(34, "sonu");
            Show(22, "paru", "f");
            Show(22, "chintu", category: "AC");
            Show(name:"bhuthu",category:"FC",age:50);
        }
        static void Show(int age,string name,string gender="M",string category="General")
        {
            Console.WriteLine("name is:"+name);
            Console.WriteLine("age is:" + age);
            Console.WriteLine("gender is:" + gender);
            Console.WriteLine("category is:" + category);
            
        }
    }
}
