﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TPLDemo
{
    class TaskDemoMain
    {
        static void Main()
        {
            //Task t = new Task(() =>
            //  {
            //      int sum = GetTotal(200, 344);
            //      Console.WriteLine(sum);
            //  });
            //t.Start();
            Task.Factory.StartNew(() =>
            {
                int sum = GetTotal(200,250);
                Console.WriteLine(sum+"sum is");
            });
            Console.ReadLine();
        }
        static int GetTotal(int start,int end)
        {
            int sum = 0;
            for(int i=start;i<end;i++)
            {
                sum = sum + i;
                Thread.Sleep(1000);
            }
            return sum;
        }
    }
}
