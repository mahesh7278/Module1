﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TPLDemo
{
    class TPLClass
    {
        static void Main()
        {
            //PrintWithhoutParallisum();
            //PrintWithParallisum();
            //Parallel.Invoke(Print1, Print1, Print2);

            Parallel.Invoke(() => SayGreeting("hiiimalli", 6),
                            () => Table(5));
            Console.ReadLine();

        }
        static void PrintWithhoutParallisum()
        {
            for (int  i= 1;i<100;i++)
            {
                Console.WriteLine(i);
                Thread.Sleep(200);

            }
        }
        static void PrintWithParallisum()
        {
            Parallel.For(1,101,(i)=>
            {
                Console.WriteLine(i);
                Task.Delay(230);
            });
        }
        static void Print()
        {
            for (int i = 1; i < 10; i++)
            {
                Console.WriteLine(i);
                Thread.Sleep(100);
            }
        }
        static void Print2()
        {
            for (int i = 201; i < 210; i++)
            {
                Console.WriteLine(i);
                Thread.Sleep(100);
            }
        }
        static void Print1()
        {
            for (int i = 101; i < 110; i++)
            {
                Console.WriteLine(i);
                Thread.Sleep(100);
            }
        }
        static void SayGreeting(string mesg,int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine(mesg);
            }
        }
        static void Table(int num)
        {
            for (int i = 0; i < 10; i++)
            {
                int res = num * i;
                Console.WriteLine(num+"*"+i+"="+res);
            }
        }
    }
}
