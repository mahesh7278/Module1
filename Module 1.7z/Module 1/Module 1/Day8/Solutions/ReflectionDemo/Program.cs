﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Sample;

namespace ReflectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly assembly = Assembly.LoadFile(@"C:\.net training\Day8\Solutions\Sample\obj\Debug\Sample.dll");
            Type[] types = assembly.GetTypes();
            foreach (var t in types)
            {
                Console.WriteLine(t.Name);
            }
            Type studentType = assembly.GetType("Sample.Student");
            PropertyInfo[] pro = studentType.GetProperties();
            foreach (var p in pro)
            {
                Console.WriteLine(p.PropertyType.Name + "" + p.Name);
            }
            MethodInfo[] met = studentType.GetMethods();
            foreach (var m in met)
            {
                Console.WriteLine(m.ReturnType.Name + "" + m.Name);
            }
            Student s = new Student();
            var studentT = s.GetType();
            var attribute = studentT.GetCustomAttributes();
            foreach (var a in attribute)
            {
                if (a is AuthorAttribute)
                {
                    var autAtt = (AuthorAttribute)a;
                    Console.WriteLine(autAtt.Name);
                    Console.WriteLine(autAtt.Modification);
                    Console.WriteLine(autAtt.Description);
                }
            }
            Console.ReadLine();
        }
    }
}
